## Türkiye İl, İlçe ve Mahalle

İl, ilçe ve mahalleler JSON formatında

- 19 Mayıs 2021'de PTT (https://postakodu.ptt.gov.tr/) sayfasından alınarak hazırlandı.
- TR-il.json 81 (4 KB)
- TR-ilce.json 973 (41 KB)
- TR-mahalle.json 73.220 (3,7 MB)

#### İlgili PTT Linki

- [PTT adres sorgulama sayfası](https://postakodu.ptt.gov.tr/)
